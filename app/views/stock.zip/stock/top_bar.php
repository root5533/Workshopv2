<?php

echo
"
    <header id='portfolio'>
        <a href='#'><img src='/w3images/avatar_g2.jpg' style='width:65px;' class='w3-circle w3-right w3-margin w3-hide-large w3-hover-opacity'></a>
        <span class='w3-button w3-hide-large w3-xxlarge w3-hover-text-grey' onclick='w3_open()'><i class='fa fa-bars'></i></span>
        <div class='w3-container'>
            <h1><b>Username (System Operator)</b></h1>
                       
           
        </div>
    </header>
    
";
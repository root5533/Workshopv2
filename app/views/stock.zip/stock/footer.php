<?php

echo
"
<footer class='w3-container w3-padding-32 w3-dark-grey footer'>
        <div class='w3-row-padding'>
            <div class='w3-third'>
                <h3>FOOTER</h3>
                <p>Praesent tincidunt sed tellus ut rutrum. Sed vitae justo condimentum, porta lectus vitae, ultricies congue gravida diam non fringilla.</p>
                <p>Powered by <a href='https://www.w3schools.com/w3css/default.asp' target='_blank'>w3.css</a></p>
            </div>

            <div class='w3-third'>
                <h3>BLOG POSTS</h3>
                <ul class='w3-ul w3-hoverable'>
                    <li class='w3-padding-16'>
                        <img src='/w3images/workshop.jpg' class='w3-left w3-margin-right' style='width:50px'>
                        <span class='w3-large'>Lorem</span><br>
                        <span>Sed mattis nunc</span>
                    </li>
                    <li class='w3-padding-16'>
                        <img src='/w3images/gondol.jpg' class='w3-left w3-margin-right' style='width:50px'>
                        <span class='w3-large'>Ipsum</span><br>
                        <span>Praes tinci sed</span>
                    </li>
                </ul>
            </div>
        </div>
    </footer>

";